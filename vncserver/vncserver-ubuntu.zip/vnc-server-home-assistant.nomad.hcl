job "vnc-firefox" {
  datacenters = ["dc1"]
  type        = "service"

  group "gui-group" {
    count = 1

    network {
      port "vnc" {
        static = 5901
      }
    }

    task "vnc-server" {
      driver = "docker"

      config {
        image = "debian:bookworm-slim"
        volumes = [
          "/media/cluster/common/vnc/firefox-for-ha/:/opt"
        ]
        command = "/bin/bash"
        args    = ["/opt/vnc-server-bootstrap.sh"]
        ports   = ["vnc"]
      }

      env {
        VNC_USER        = "nomaduser"
        USER_PASS       = "clusterpassword123"
        VNC_SERVER_PASS = "vncpassword"
        DEBIAN_FRONTEND = "noninteractive"
      }

      resources {
        cpu    = 2000
        memory = 2000
      }
    }
  }
}