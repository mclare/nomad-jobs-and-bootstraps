#!/bin/bash
set -e

date
echo "1. System-level setup (as root)"
apt up
apt install -y sudo tigervnc-standalone-server xfce4 xfce4-goodies dbus-x11 firefox-esr

date
echo "2. User-level setup (as $VNC_USER)"
if ! id -u "$VNC_USER" >/dev/null 2>&1; then
    useradd -m -s /bin/bash "$VNC_USER"
    echo "$VNC_USER:$USER_PASS" | chpasswd
    usermod -aG sudo "$VNC_USER"
fi

date
echo "3. Configuring VNC for $VNC_USER"
# We use sudo -u to run commands as the user while keeping env vars available
sudo -u "$VNC_USER" -H bash -c <<EOF
    mkdir -p ~/.vnc
    echo "$VNC_SERVER_PASS" | vncpasswd -f > ~/.vnc/passwd
    chmod 600 ~/.vnc/passwd

    # Setup xstartup
    echo '#!/bin/sh' > ~/.vnc/xstartup
    echo 'xrdb \$HOME/.Xresources' >> ~/.vnc/xstartup
    echo 'exec startxfce4' >> ~/.vnc/xstartup
    chmod +x ~/.vnc/xstartup

    # Clean and Start
    vncserver -kill :1 2>/dev/null || true
    vncserver -localhost no :1
EOF

date
echo "VNC Server setup complete. Access it or port 5901 with password: $VNC_SERVER_PASS"
# 4. Keep the container alive by tailing the user's VNC log
# This identifies the log file dynamically based on hostname
echo "VNC Server started for $VNC_USER. Tailing logs..."
tail -f /home/"$VNC_USER"/.vnc/*.log

echo "Keeping container alive after incident..."
while true; do date; sleep 30; done;